
SmokeDataSet_v2 - v3 H_Flip_Brightness
==============================

This dataset was exported via roboflow.ai on August 21, 2020 at 10:02 PM GMT

It includes 1886 images.
Smoke are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* Random brigthness adjustment of between 0 and +23 percent


